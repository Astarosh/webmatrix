jQuery(document).ready(function($) {
	//first started with pure js...
	document.getElementById("add-more").addEventListener("click", addMoreField);
	function addMoreField() {
		var itm = document.getElementById("upload-form").getElementsByClassName("fileform");
		var itms_length = itm.length;
		var cln = itm[0].cloneNode(true);
		cln.getElementsByTagName("div")[1].innerHTML = "Фото - Загрузка - "+(itms_length+1)+"";
		cln.getElementsByTagName("img")[0].src = "";
		cln.getElementsByTagName("img")[0].removeAttribute("data-success");
		cln.getElementsByTagName("input")[0].value = "";
		cln.getElementsByClassName("selectbutton")[0].removeAttribute('style');
		document.getElementById("upload-form").appendChild(cln);
	}
	
	function rtrim(str){
		var result = str.replace(/\/+$/, '');
		return result;

	}
	$('.save_files').click(function(){
		var data = $('#upload-form').serialize();
		$.ajax({
			url: 'tool/send_mail.php',
            type: 'post',
            dataType: 'json',
            data: data,
            success: function (json) {
				if (json['success']) {
			        if(confirm(json['success']) || !confirm(json['success'])){
						window.location.reload();  
					}
				}
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});
	});
	$(document).on("click", '.fileform', function() {
		var node = this;
		if($(node).find('.thumbnail-img img').attr('data-success') == 1){
		} else {
			
			$('#form-upload').remove();
			$('body').prepend('<form enctype="multipart/form-data" id="form-upload" style="display: none;"><input type="file" name="file" /></form>');
			$('#form-upload input[name=\'file\']').trigger('click');
			
			if (typeof timer != 'undefined') {
				clearInterval(timer);
			}
			timer = setInterval(function() {
				if ($('#form-upload input[name=\'file\']').val() != '') {
					clearInterval(timer);
					var file_size = $('#form-upload input[name=\'file\']').get(0).files[0].size;
					if(file_size < 1048576){
						var data = new FormData($('#form-upload')[0]);
						$.ajax({
							url: 'tool/upload_image.php',
							type: 'post',
							dataType: 'json',
							data: data,
							cache: false,
							contentType: false,
							processData: false,
							success: function(json) {
								$('.text-danger').remove();
								
								if (json['error']) {
									$(node).find('input').after('<div class="text-danger">' + json['error'] + '</div>');
								}
								
								if (json['success']) {
									alert(json['success']);
									$('.table-result').fadeIn(400);
									var $clone = $('.example-row').clone();
									$clone.removeClass('example-row');
									$clone.find('img').attr('src', rtrim(window.location.href)+json['src']);
									$clone.find('p').text(json['size']);
									$('.table-result tbody').append($clone);
									
									$(node).find('.label-name').text('Успешно загружено!');
									$(node).find('input').attr('value', rtrim(window.location.href)+json['src']);
									$(node).find('.thumbnail-img img').attr('src', rtrim(window.location.href)+json['src']);
									$(node).find('.selectbutton').css('background','green');
									$(node).find('.thumbnail-img img').attr('data-success', 1);
								}
							},
							error: function(xhr, ajaxOptions, thrownError) {
								alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
							}
						});
					} else{
						alert('Слишком большой файл!');
					}
				} 
			}, 500);
	    }
	});
});