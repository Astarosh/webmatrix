<?php

//Some support functions
//Add to db values
function addTodb($filename, $filename_disk, $fileurl){
	global $conn;
	$sql = $conn->prepare("INSERT INTO imgageUpload (filename, filename_disk, fileurl) VALUES (?, ?, ?)");
	$sql->bind_param("sss", $filename, $filename_disk, $fileurl);
	$sql->execute();
}

//Change end of words depending on number
function plural_form($number, $after) {
    $cases = array(2, 0, 1, 1, 1, 2);
    return $number . ' ' . $after[($number % 100 > 4 && $number % 100 < 20) ? 2 : $cases[min($number % 10, 5)]];
}

//Some changes to result filesize
function formatSizeUnits($bytes){
    if ($bytes >= 1073741824){
		$bytes = number_format($bytes / 1073741824, 2) . ' GB';
	}
	elseif ($bytes >= 1048576){
		$bytes = number_format($bytes / 1048576, 1) . ' MB';
	}
	elseif ($bytes >= 1024){
		$bytes = number_format($bytes / 1024, 1) . ' KB';
	}
	elseif ($bytes > 1){
		$bytes = $bytes . ' bytes';
	}
	elseif ($bytes == 1){
		$bytes = $bytes . ' byte';
	}
	else{
		$bytes = '0 bytes';
	}
	return $bytes;
}

//Hate cyrrilic, so some changes to file names
function cyrSortMask($string) {
    $tr = array(
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => '1', 'ж' => 'j', 'з' => 'z',
        'и' => 'i', 'й' => '2', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
        'у' => 'y', 'ф' => 'f', 'х' => 'x', 'ц' => 'c', 'ч' => '3', 'ш' => '4', 'щ' => '5', 'ъ' => '6', 'ы' => '7', 'э' => '8', 'ю' => '9', 'я' => 'u',
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => '0', 'Ж' => 'J', 'З' => 'Z',
        'И' => 'I', 'Й' => '___', 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
        'У' => 'Y', 'Ф' => 'F', 'Х' => 'X', 'Ц' => 'C', 'Ч' => '--', 'Ш' => '---', 'Щ' => '----', 'Ъ' => '____', 'Ы' => '-----', 'Э' => '_____', 'Ю' => '------', 'Я' => '______', ' ' => '__',
        'ь' => 'q', 'Ь' => '----------'
    );

    return strtr($string, $tr);
}

function cyrSortDeMask($string) {
    $tr = array(
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => '1', 'ж' => 'j', 'з' => 'z',
        'и' => 'i', 'й' => '2', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
        'у' => 'y', 'ф' => 'f', 'х' => 'x', 'ц' => 'c', 'ч' => '3', 'ш' => '4', 'щ' => '5', 'ъ' => '6', 'ы' => '7', 'э' => '8', 'ю' => '9', 'я' => 'u',
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => '0', 'Ж' => 'J', 'З' => 'Z',
        'И' => 'I', 'Й' => '___', 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
        'У' => 'Y', 'Ф' => 'F', 'Х' => 'X', 'Ц' => 'C', 'Ч' => '--', 'Ш' => '---', 'Щ' => '----', 'Ъ' => '____', 'Ы' => '-----', 'Э' => '_____', 'Ю' => '------', 'Я' => '______', ' ' => '__',
        'ь' => 'q', 'Ь' => '----------'
    );

    return strtr($string, array_flip($tr));
}

 ?>