<?php
include "db.php";
include "support_function.php";

$filePath  = $_FILES['file']['tmp_name'];
$errorCode = $_FILES['file']['error'];
$size = $_FILES['file']['size'];

//5MB size limit
$size_limit = 1048576*5;

//Check for success upload
if ($errorCode !== UPLOAD_ERR_OK || !is_uploaded_file($filePath)) {
    $errorMessages = [
        UPLOAD_ERR_INI_SIZE   => 'Размер файла превысил значение upload_max_filesize в конфигурации PHP.',
        UPLOAD_ERR_FORM_SIZE  => 'Размер загружаемого файла превысил значение MAX_FILE_SIZE в HTML-форме.',
        UPLOAD_ERR_PARTIAL    => 'Загружаемый файл был получен только частично.',
        UPLOAD_ERR_NO_FILE    => 'Файл не был загружен.',
        UPLOAD_ERR_NO_TMP_DIR => 'Отсутствует временная папка.',
        UPLOAD_ERR_CANT_WRITE => 'Не удалось записать файл на диск.',
        UPLOAD_ERR_EXTENSION  => 'PHP-расширение остановило загрузку файла.',
    ];
    $unknownMessage = 'При загрузке файла произошла неизвестная ошибка.';
    $outputMessage = isset($errorMessages[$errorCode]) ? $errorMessages[$errorCode] : $unknownMessage;
    die($outputMessage);
}

$json = array();
//Some validation
if (!empty($_FILES['file']['name']) && is_file($filePath)) {
	$filename = rawurldecode(basename(rawurlencode(html_entity_decode($_FILES['file']['name'], ENT_QUOTES, 'UTF-8'))));
	
	if($size_limit < $size){
		$json['error'] = "Слишком большой файл";
	}
	if ((strlen(utf8_decode(filename)) < 3) || (strlen(utf8_decode(filename)) > 64)) {
		$json['error'] = "Недопустимая длина файла";
	}
	$fi = finfo_open(FILEINFO_MIME_TYPE);
	$mime = (string) finfo_file($fi, $filePath);
	if (strpos($mime, 'image') === false){
	   $json['error'] = "Недопустимый тип файла";
	}
} else{
	$json['error'] = "Ошибка при загрузке файла!";
}

//If no errors...
if (!$json) {
	$file = cyrSortMask($filename);
	$file_name = explode('.', $file);
	$file_name_end = end($file_name);
	$upload_to_directory = '../upload/'. $file;
	$i = 1;
	$file_name_new = $file;
    $maxDim = 500;
	list($width, $height, $type, $attr) = getimagesize( $filePath );
	
	//File unique name
	if (file_exists($upload_to_directory)) {
		while(file_exists($upload_to_directory)){
			$upload_to_directory = '../upload/'. $file_name_new;
			$i++;
		}
	}
	
	//Check for too wide(height or width) file
	if ( $width > $maxDim || $height > $maxDim ) {
		$file_name_new = $file_name[0].'-resized.'.$file_name_end;
		$upload_to_directory = '../upload/'. $file_name_new;
		$target_filename = $filePath;
		$ratio = $width/$height;
		if( $ratio > 1) {
			$new_width = $maxDim;
			$new_height = $maxDim/$ratio;
		} else {
			$new_width = $maxDim*$ratio;
			$new_height = $maxDim;
		}
		$src = imagecreatefromstring( file_get_contents( $filePath ) );
		$dst = imagecreatetruecolor( $new_width, $new_height );
		imagecopyresampled( $dst, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height );
		imagedestroy( $src );
		imagepng( $dst, $upload_to_directory ); // adjust format as needed
		imagedestroy( $dst );
	} else{
		move_uploaded_file($filePath, $upload_to_directory);
	}
	$json['src'] = '/upload/' . $file_name_new;
	$json['success'] = "Файл успешно закачан";
	$json['size'] = formatSizeUnits(filesize($upload_to_directory));
	
	//Add to db file info
	addTodb($file, $file_name_new, $upload_to_directory);
}
$conn->close();
echo json_encode($json, JSON_UNESCAPED_UNICODE);
?>