<?php 

include "support_function.php";
$json = array();

// Check for valid POST
if (isset($_POST['upload']) && !empty($_POST['upload'])) {

	$get_arr = $_POST;
	$json['urls'] = $get_arr['upload'];
	$json['count'] = count($get_arr['upload']);
	$msg="<p>Заполнена форма обратной связи</p>";
	$msg.="<p>Закачано: ".plural_form(count($get_arr['upload']), ["изображение", "изображения", "изображений"])."!</p>";
	$msg.="<p>Картинки доступны по следующим Url:</p>";
	foreach($get_arr['upload'] as $upload){
		$msg.="<p>".$upload."</p>";
	}
	
	//Change email here
	$to = 'sviataslaukarshakevi4@gmail.com';
	
	$subject = "Загружены новые фото!";
	$headers = "From: test_task_site \r\n";
	$headers .= "Reply-To: sviataslaukarshakevi4@gmail.com\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
	if(@mail($to, $subject, $msg, $headers)){
	  $json['success'] = "Email успешно отправлен!";
	}else{
	  $json['success'] = "Что-то пошло не так при отправке :(";
	}
} else{
	$json['success'] = "Что-то пошло не так при отправке :(";
}
echo json_encode($json, JSON_UNESCAPED_UNICODE);
?>