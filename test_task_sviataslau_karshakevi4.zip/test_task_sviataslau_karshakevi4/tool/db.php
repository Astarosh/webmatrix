<?php

//Here change ur db connections
$servername = "localhost";
$username = "astik";
$password = "x527QKOe";
$dbname = "user1111744_testovaia";

//Check for available connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Create table if not exist
$query = "SELECT ID FROM imgageUpload";
$result = $conn->query($query);
if(empty($result)) {
	$sql = "CREATE TABLE imgageUpload (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	filename VARCHAR(64) NOT NULL,
	filename_disk VARCHAR(64) NOT NULL,
	fileurl VARCHAR(100)
	)";
	$result = $conn->query($sql);
}
?>